package com.example.mention.data

import com.google.gson.annotations.SerializedName

data class InputUser(

	@field:SerializedName("input")
	val input: String? = null
)
