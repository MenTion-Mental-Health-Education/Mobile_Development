package com.example.mention.utils

object Constant {
    const val SEND_ID = "SEND_ID"
    const val RECEIVE_ID = "RECEIVE_ID"
    const val CONSUL_ID = "RECEIVE_ID"


    const val OPEN_GOOGLE = "Opening Google......"
    const val OPEN_SEARCH = "Searching......"
    const val CONSUL = "Conect to consultant.........."
}